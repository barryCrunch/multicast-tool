# Multicast-Tool
A small multicast tool that can be used to test communication. It has the ability to both send and receive data

## Receive Data

## Send Data


